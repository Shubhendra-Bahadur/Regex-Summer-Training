function possibleOrNot(string1,string2,k){
	if((string1.length)>k) {
		console.log("Task2 ans is:","No");

	}else{
		console.log("Task2 ans is:","Yes");
	}	
}

possibleOrNot('Shubhendra','shu',2);